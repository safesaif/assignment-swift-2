import Cocoa

let testArray: [Int] = [2, 7, 11, 15]
let targetSum : Int = 13

twoSum(testArray,  targetSum)

 func twoSum(_ nums: [Int], _ target: Int) {
    for num in nums{
        for iterateNum in nums {
            if (nums[num] + nums[iterateNum] == target) {
                print([nums[num], nums[iterateNum]])
            }
        }
    }
}
