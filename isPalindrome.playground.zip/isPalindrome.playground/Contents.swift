/* Takes in a string as input. It is assumed here that the string is consisted
 purely of alphabet letters, and an empty string or single character is
 considered a palindrome.
*/

import Swift

let string = "asdfdsa"
var is_palindrome = isPalindrome(string)


func isPalindrome(_ word: String) -> Bool {
    let string = String(word.lowercased())
    let reversedString = String(string.reversed())
    
    if reversedString == word {
        print("The string is a palindrome.")
        return true;
    }
    else {
        print("The string is not a palindrome.")
        return false;
    }
}

/* Palindrome Testcases:
"abba"
""
"s"
"radar"
"R a D a R"
"A S D F D S A"
"a S d F d S a"
*/

/* Not a Palindrome Testcases:
"boy"
"Swift"
"abab"
"lkll"
"abbas"
" h  "
 */



